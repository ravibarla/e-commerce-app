import dotenv from "dotenv";
//load all the environemt variable
dotenv.config();

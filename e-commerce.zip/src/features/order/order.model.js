export default class OrderModel {
  constructor(userId, totalamount, timestamp) {
    (this.userId = userId),
      (this.totalamount = totalamount),
      (this.timestamp = timestamp);
  }
}
